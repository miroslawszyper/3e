﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class Person
    {
        public string name = "";
        public string surname = "";


        public Person() { }
        public Person(string _name, string _surname) 
        { 
            name = _name;
            surname = _surname;
        }

        public string Info()
        {
            return "Imię i nazwisko: " + name + " " + surname;
        }

    }
}
