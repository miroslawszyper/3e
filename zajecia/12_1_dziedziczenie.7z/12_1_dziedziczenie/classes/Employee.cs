﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class Employee : Person
    {
        public float ratePerHour = 0;
        public byte numberOfHours = 0;
        
        public Employee(string _name, string _surname, float _ratePerHour) 
        {
            name = _name;
            surname = _surname;
            ratePerHour = _ratePerHour;
        }

        public Employee(string _name, string _surname, float _ratePerHour, byte _numberOfHours)
        {
            name = _name;
            surname = _surname;
            ratePerHour = _ratePerHour;
            numberOfHours = _numberOfHours;
        }

        public float Salary()
        {
            return ratePerHour * numberOfHours;
        }

        public string Info()
        {
            return "Imię i nazwisko: " + name + " " + surname + ", pensja: " + Salary() + "zł";
        }
    }
}
