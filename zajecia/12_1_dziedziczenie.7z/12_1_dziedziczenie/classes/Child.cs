﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class Child : Person
    {
        public string classAtSchool = "";

        public Child(string _name, string _surname, string _classAtSchool)
        {
            name = _name;
            surname = _surname;
            classAtSchool = _classAtSchool;
        }

        public string Info()
        {
            return "Imię i nazwisko: " + name + " " + surname + ", klasa: " + classAtSchool;
        }
    }
}
