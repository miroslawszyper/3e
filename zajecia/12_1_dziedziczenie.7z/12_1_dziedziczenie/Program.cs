﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person("Janusz", "Kowalski");
            Console.WriteLine("Osoba: " + p.Info()); 

            Employee e = new Employee("Anna", "Nowak", 40.50f, 168);
            Console.WriteLine("Pracownik: " + e.Info());

            Child c = new Child("Tomasz", "Kowalski", "1Ti");
            Console.WriteLine("Dziecko: " + c.Info());

        }
    }
}